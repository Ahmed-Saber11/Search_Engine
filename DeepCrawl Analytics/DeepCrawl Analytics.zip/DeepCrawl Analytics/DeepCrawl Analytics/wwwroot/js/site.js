﻿$(document).ready(function () {
    // Search functionality
    $('#searchInput').on('input', function () {
        var query = $(this).val().trim();
        if (query.length > 0) {
            $('.loader').show();
            $('#resultsContainer').hide();

            $.get('/Search/Search', { term: query })
                .done(function (data) {
                    console.log("Search results:", data);
                    displayResults(data);
                })
                .fail(function (jqXHR, textStatus, errorThrown) {
                    console.error("Search error:", textStatus, errorThrown);
                    displayError();
                })
                .always(function () {
                    $('.loader').hide();
                });
        } else {
            $('#resultsContainer').hide();
            if ($.fn.DataTable.isDataTable('#resultsTable')) {
                $('#resultsTable').DataTable().destroy();
            }
        }
    });

    // Dark mode toggle
    $('#darkModeSwitch').change(function () {
        $('body').toggleClass('dark-mode');
        localStorage.setItem('darkMode', $(this).is(':checked'));
    });

    // Load dark mode preference
    if (localStorage.getItem('darkMode') === 'true') {
        $('#darkModeSwitch').prop('checked', true);
        $('body').addClass('dark-mode');
    }

    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn();
        } else {
            $('.back-to-top').fadeOut();
        }
    });

    $('.back-to-top').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 'smooth');
    });

    // Card animations
    animateCards();
});

// Display search results
function displayResults(data) {
    if (!data || !data.results || data.results.length === 0) {
        $('#resultsContainer').html('<div class="alert alert-info">No results found</div>').show();
        return;
    }

    // تدمير الجدول الحالي إن وجد
    if ($.fn.DataTable.isDataTable('#resultsTable')) {
        $('#resultsTable').DataTable().destroy();
    }

    // إنشاء الجدول باستخدام DataTables
    $('#resultsTable').DataTable({
        responsive: true,
        data: data.results,
        columns: [
            {
                data: 'url',
                render: function (data) {
                    return '<a href="' + data + '" target="_blank">' + data + '</a>';
                }
            },
            { data: 'count' },
            { data: 'snippet' }
        ]
    });

    $('#resultsContainer').show();
}
function displayError() {
    $('#resultsContainer').html(`
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle me-2"></i>
            Error loading search results. Please try again.
        </div>
    `).show();
}

// Animate cards on scroll
function animateCards() {
    $('.card').each(function () {
        var cardPos = $(this).offset().top;
        var scrollPos = $(window).scrollTop() + $(window).height();
        if (cardPos < scrollPos) {
            $(this).animate({ opacity: 1, marginTop: 0 }, 500);
        }
    });
}