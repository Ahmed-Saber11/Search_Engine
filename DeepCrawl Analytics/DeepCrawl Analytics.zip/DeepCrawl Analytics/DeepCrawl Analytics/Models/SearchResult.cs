﻿namespace DeepCrawl_Analytics.Models
{
	public class SearchResult
	{
		public string Url { get; set; }
		public int Count { get; set; }
		public string Snippet { get; set; }
	}
}
