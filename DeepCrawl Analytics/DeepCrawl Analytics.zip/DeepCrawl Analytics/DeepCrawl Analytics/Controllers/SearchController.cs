﻿using DeepCrawl_Analytics.Models;
using Microsoft.AspNetCore.Mvc;

namespace DeepCrawl_Analytics.Controllers
{
	public class SearchController : Controller
	{
		public IActionResult Index()
		{
			return View();
		}
        [HttpGet]
        public IActionResult Search(string term)
        {
            var mockResults = new List<SearchResult>
    {
        new SearchResult {
            Url = "https://example.com/page1",
            Count = 15,
            Snippet = $"Search result for {term}"
        },
        new SearchResult {
            Url = "https://example.com/page2",
            Count = 8,
            Snippet = $"More info about {term}"
        }
    };

            return Json(new
            {
                totalResults = mockResults.Count,
                results = mockResults
            });
        }
    }
}
